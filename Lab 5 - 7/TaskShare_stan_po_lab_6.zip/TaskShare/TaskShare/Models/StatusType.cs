﻿namespace TaskShare.Models
{
    public enum StatusType
    {
        Opened,
        Closed
    }
}