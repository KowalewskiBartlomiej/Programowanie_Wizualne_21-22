﻿namespace TaskShare.Algorithms
{
    public class OneOfTheWeightNonPositiveException: Exception
    {
    }
}
