﻿namespace TaskShare.Algorithms
{
    public class UnsupportedSubsetsCountException: Exception
    {
    }
}
