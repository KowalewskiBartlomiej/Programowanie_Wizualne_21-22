﻿namespace TaskShare.Algorithms
{
    public class CannotBeSplitException: Exception
    {
    }
}
